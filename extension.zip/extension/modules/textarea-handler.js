// =============================================================================
// Textarea Handler - Updates GitHub's blob textarea
// =============================================================================

window.TextareaHandler = class TextareaHandler {
  constructor(selectors) {
    this.selectors = selectors;

    this.originalValue = null;
    this.originalReadOnly = null;
    this.originalAriaReadOnly = null;
    this.originalHasReadOnlyAttr = null;
  }

  /**
   * Update the existing textarea value with Python code.
   *
   * GitHub manages this textarea via React; replacing the DOM node (clone/replaceChild)
   * can break internal refs/layout and intermittently blank the code view.
   *
   * If you need to "force" changes despite readonly, do it in-place:
   * temporarily remove readonly/aria-readonly, set value, then restore.
   */
  replaceWithPython(pythonCode) {
    const textarea = document.querySelector(this.selectors.codeTextarea);
    if (!textarea) {
      console.warn("[Lens] Textarea not found for replacement");
      return null;
    }

    if (this.originalValue === null) {
      this.originalValue = textarea.value;
      this.originalReadOnly = textarea.readOnly;
      this.originalAriaReadOnly = textarea.getAttribute("aria-readonly");
      this.originalHasReadOnlyAttr = textarea.hasAttribute("readonly");
    }

    // Temporarily lift readonly so GitHub/React doesn't ignore mutations.
    // (Setting textarea.value works even if readonly, but this is the safest.)
    textarea.readOnly = false;
    textarea.removeAttribute("readonly");
    textarea.removeAttribute("aria-readonly");

    textarea.value = pythonCode;
    textarea.textContent = pythonCode;

    // Restore readonly state/attrs to what GitHub expects.
    textarea.readOnly = this.originalReadOnly ?? true;
    if (this.originalHasReadOnlyAttr) textarea.setAttribute("readonly", "true");
    if (this.originalAriaReadOnly !== null) {
      textarea.setAttribute("aria-readonly", this.originalAriaReadOnly);
    } else {
      textarea.setAttribute("aria-readonly", "true");
    }

    console.log(
      "[Lens] Textarea value updated with Python code, length:",
      pythonCode.length
    );

    return this.originalValue;
  }

  /**
   * Restore original textarea content
   */
  restore() {
    if (this.originalValue === null) {
      return;
    }

    const textarea = document.querySelector(this.selectors.codeTextarea);
    if (!textarea) {
      console.warn("[Lens] Textarea not found for restore");
      this.reset();
      return;
    }

    textarea.readOnly = false;
    textarea.removeAttribute("readonly");
    textarea.removeAttribute("aria-readonly");
    textarea.value = this.originalValue;
    textarea.textContent = this.originalValue;

    textarea.readOnly = this.originalReadOnly ?? true;
    if (this.originalHasReadOnlyAttr) textarea.setAttribute("readonly", "true");
    if (this.originalAriaReadOnly !== null) {
      textarea.setAttribute("aria-readonly", this.originalAriaReadOnly);
    } else {
      textarea.setAttribute("aria-readonly", "true");
    }

    this.reset();
    console.log("[Lens] Original textarea value restored");
  }

  /**
   * Reset state
   */
  reset() {
    this.originalValue = null;
    this.originalReadOnly = null;
    this.originalAriaReadOnly = null;
    this.originalHasReadOnlyAttr = null;
  }
};
